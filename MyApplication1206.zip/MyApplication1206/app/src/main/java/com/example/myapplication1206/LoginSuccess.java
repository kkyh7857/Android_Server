package com.example.myapplication1206;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class LoginSuccess extends AppCompatActivity {
    private TextView tv_login_id, tv_login_pw, tv_login_nick, tv_login_phone;
    private Button btn_chatMove;
    private AndMemberVO info;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_success);

        tv_login_id = findViewById(R.id.tv_login_id);
        tv_login_pw = findViewById(R.id.tv_login_pw);
        tv_login_nick = findViewById(R.id.tv_login_nick);
        tv_login_phone = findViewById(R.id.tv_login_phone);
        btn_chatMove = findViewById(R.id.btn_chatMove);

        Intent intent = getIntent();
        AndMemberVO info = (AndMemberVO) intent.getSerializableExtra("info");
        tv_login_id.setText(info.getId());
        tv_login_pw.setText(info.getPw());
        tv_login_nick.setText(info.getNick());
        tv_login_phone.setText(info.getPhone());

        btn_chatMove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(LoginSuccess.this, Chat.class);
                intent1.putExtra("info", info);
                startActivity(intent1);
            }
        });

    }
}