package com.example.myapplication1206;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.lang.reflect.Member;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private Button btn_joinMove, btn_LoginMove, btn_listMove;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_joinMove = findViewById(R.id.btn_joinMove);
        btn_LoginMove = findViewById(R.id.btn_LoginMove);
        btn_listMove = findViewById(R.id.btn_listMove);


        btn_joinMove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Join.class);
                startActivity(intent);
            }
        });

        btn_LoginMove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Login.class);
                startActivity(intent);
            }
        });

        btn_listMove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, MemberList.class);
                startActivity(intent);
            }
        });
    }
}