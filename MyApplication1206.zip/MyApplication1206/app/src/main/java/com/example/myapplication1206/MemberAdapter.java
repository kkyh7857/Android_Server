package com.example.myapplication1206;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class MemberAdapter extends BaseAdapter{

    private ArrayList<AndMemberVO> items = new ArrayList<AndMemberVO>();

    public void addItems(String id, String pw, String nick, String phone){
        AndMemberVO vo = new AndMemberVO(id, pw, nick, phone);
        items.add(vo);
    }

    @Override
    // 리스트의 크기를 알려주는 메소드
    public int getCount() {
        return items.size();
    }

    @Override
    // 리스트의 특정 위치에 있는 데이터 전송
    public Object getItem(int position) {
        return items.get(position);
    }

    @Override
    // 잘 안 씀. 데이터 위치 전송
    public long getItemId(int position) {
        return position;
    }

    @Override
    // ArrayList 의 수만큼 동작한다.
    public View getView(int position, View convertView, ViewGroup parent) {

        Context context = parent.getContext();

        //convertView : 새롭게 만든 listview 의 정보를 가지고 있는 녀석.
        if(convertView == null){
            // LayoutInflater : XML 에 미리 정의해둔 틀을 실제 메모리에 올려주는 역할
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.memberlayout, parent, false);
        }
        // memberlayout.xml 에 있는 정보를 convertView 를 통해 가지고 옴.
        TextView tv_list_id =  convertView.findViewById(R.id.tv_list_id);
        TextView tv_list_pw =  convertView.findViewById(R.id.tv_list_pw);
        TextView tv_list_nick =  convertView.findViewById(R.id.tv_list_nick);
        TextView tv_list_phone =  convertView.findViewById(R.id.tv_list_phone);

        // 리스트에 있는 정보를 만들어 둔 vo 에 저장.
        AndMemberVO vo = items.get(position);

        // 만들어 둔 텍스트 뷰에 받은 정보를 넣는다.
        tv_list_id.setText(vo.getId());
        tv_list_pw.setText(vo.getPw());
        tv_list_nick.setText(vo.getNick());
        tv_list_phone.setText(vo.getPhone());

        // 마지막으로 그 모든 정보를 가지고 있는 convertView 를 리턴해준다.
        return convertView;

    }
}
